# CC-MC — Chilling Centre Milk Collection & Device Integration System

MVP vertical slice: Login -> RBAC + centre scope -> Source/Vehicle ->
Milk Reception -> Quality Validation -> Accept/Reject/Hold -> Manager
Override -> Audit -> Dashboard.

Real device integration (RS232/Bluetooth, the Local Device Gateway) is
**not** part of this slice - see `docs/architecture.md` for what was and
wasn't built, and why.

## Prerequisites

- Node.js 20+ and pnpm (`corepack enable` or `npm install -g pnpm`)
- PostgreSQL 16 running locally (or reachable via `DATABASE_URL`)

## First-time setup

```bash
# 1. Install all workspace dependencies
pnpm install

# 2. Build the shared types package (both apps depend on its compiled output)
pnpm --filter @cc-mc/shared-types build

# 3. Create the two local databases
createdb ccmc_dev
createdb ccmc_test

# 4. Configure the API's environment
cp apps/api/.env.example apps/api/.env
# edit apps/api/.env if your local Postgres uses different credentials/port.
# apps/api/.env.test is committed as-is (test DB only, no real secrets).

# 5. Run database migrations (against ccmc_dev, via DATABASE_URL in apps/api/.env)
cd apps/api
pnpm migration:run

# 6. Seed reference/demo data (roles, permissions, 2 centres, 4 users, quality rules, sample sources/vehicles)
pnpm seed
```

Seeded users (all local-dev-only passwords):

| Email | Password | Role | Centre |
|---|---|---|---|
| admin@ccmc.local | Admin@12345 | Admin | All centres |
| manager1@ccmc.local | Manager@12345 | Manager | Bangalore |
| operator1@ccmc.local | Operator@12345 | Operator | Bangalore |
| operator2@ccmc.local | Operator@12345 | Operator | Mysore |

## Running locally

```bash
# Terminal 1 - API (http://localhost:3000)
cd apps/api
pnpm start:dev

# Terminal 2 - Web (http://localhost:5173, proxies /api to the API)
cd apps/web
pnpm dev
```

Open http://localhost:5173, log in as `operator1@ccmc.local`, create a
reception (try FAT outside 3.0-6.0 to see it go to HOLD), then log in as
`manager1@ccmc.local` in another browser/incognito window to override the
HOLD.

## Tests

```bash
cd apps/api

# Unit tests (business logic - quality validation, etc.)
pnpm test

# Integration/e2e tests (real Postgres test DB, real RBAC guards, real HTTP requests)
pnpm test:e2e
```

`test:e2e` runs against `ccmc_test` (configured in `apps/api/.env.test`),
resetting and reseeding the schema before the suite via
`test/global-setup.ts`. It does not touch `ccmc_dev`.

## Repository layout

```
apps/
  api/      NestJS backend (see apps/api/src for module boundaries)
  web/      React + Vite frontend
packages/
  shared-types/   DTOs, enums, and permission codes shared by api + web
docs/
  architecture.md   As-built architecture summary
  assumptions.md    Every MVP default assumed where the BRD was ambiguous
  adr/              Architecture decision records
BRD/                 Original business requirements document
Engineering Analysis/  Prior analysis + implementation proposal
```

`apps/gateway` and `packages/device-adapters` do not exist yet - see
`docs/architecture.md` for why, and the implementation proposal for the
plan once real device specifications are available.

## Known limitations of this slice

See `docs/assumptions.md` for the full list. The short version: transaction
numbering is a simplified `{centreCode}-{id}` scheme (not the offline-safe
scheme a real gateway will need), quality rules are seeded globally only
(no per-centre or per-milk-type overrides yet, though the schema supports
them), rejection/hold reasons are free text, and there is no formatted
receipt, reporting beyond the dashboard, or admin UI for
users/roles/permissions.
