import { Injectable, UnauthorizedException } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { Repository } from "typeorm";
import { JwtService } from "@nestjs/jwt";
import * as bcrypt from "bcrypt";
import { RecordStatus, type LoginResponse } from "@cc-mc/shared-types";
import { User } from "./entities/user.entity";
import { UserRole } from "../rbac/entities/user-role.entity";
import { UserCentreAssignment } from "../rbac/entities/user-centre-assignment.entity";
import { AuditService } from "../audit/audit.service";
import type { RequestUser } from "../rbac/rbac.types";

@Injectable()
export class AuthService {
  constructor(
    @InjectRepository(User) private readonly userRepo: Repository<User>,
    @InjectRepository(UserRole) private readonly userRoleRepo: Repository<UserRole>,
    @InjectRepository(UserCentreAssignment)
    private readonly centreAssignmentRepo: Repository<UserCentreAssignment>,
    private readonly jwtService: JwtService,
    private readonly audit: AuditService,
  ) {}

  /**
   * Loads a user's roles, permissions, and centre access fresh from the
   * database. Called both by the login flow and by JwtStrategy on every
   * authenticated request - see rbac.types.ts for why this isn't cached.
   */
  async loadUserContext(userId: number): Promise<RequestUser | null> {
    const user = await this.userRepo.findOneBy({ id: userId });
    if (!user || user.status !== RecordStatus.ACTIVE) return null;

    const userRoles = await this.userRoleRepo.find({
      where: { userId },
      relations: { role: { rolePermissions: { permission: true } } },
    });
    const centreAssignments = await this.centreAssignmentRepo.find({ where: { userId } });

    const roleNames = userRoles.map((ur) => ur.role.name);
    const permissionCodes = Array.from(
      new Set(userRoles.flatMap((ur) => ur.role.rolePermissions.map((rp) => rp.permission.code))),
    );

    const allCentres = centreAssignments.some((a) => a.allCentres);
    const centreIds = centreAssignments
      .filter((a) => !a.allCentres && a.centreId !== null)
      .map((a) => a.centreId as number);

    return {
      id: user.id,
      email: user.email,
      fullName: user.fullName,
      roleNames,
      permissionCodes,
      centreAccess: { allCentres, centreIds },
    };
  }

  async login(email: string, password: string): Promise<LoginResponse> {
    const user = await this.userRepo.findOneBy({ email });
    if (!user || user.status !== RecordStatus.ACTIVE) {
      throw new UnauthorizedException("Invalid credentials");
    }

    const passwordMatches = await bcrypt.compare(password, user.passwordHash);
    if (!passwordMatches) {
      throw new UnauthorizedException("Invalid credentials");
    }

    const context = await this.loadUserContext(user.id);
    if (!context) {
      throw new UnauthorizedException("Invalid credentials");
    }

    const accessToken = this.jwtService.sign({ sub: user.id, email: user.email });

    await this.audit.record({
      userId: user.id,
      centreId: null,
      action: "LOGIN",
      resourceType: "User",
      resourceId: String(user.id),
    });

    return {
      accessToken,
      user: {
        id: context.id,
        email: context.email,
        fullName: context.fullName,
        roles: context.roleNames,
        permissions: context.permissionCodes as LoginResponse["user"]["permissions"],
        centreAccess: context.centreAccess,
      },
    };
  }
}
