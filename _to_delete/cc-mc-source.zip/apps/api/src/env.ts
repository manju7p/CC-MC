/**
 * Loads apps/api/.env (or .env.test, when overridden by a test setup file
 * that runs first) into process.env. Imported for its side effect only -
 * must be the first import in any entrypoint (main.ts, data-source.ts,
 * seed.ts) so environment variables are available before anything else in
 * that file is evaluated.
 */
import * as dotenv from "dotenv";

dotenv.config();
